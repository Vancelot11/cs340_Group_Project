drop table User_favorites;

drop table Restaurant_address;
drop table Restaurant_hours;
drop table Restaurant_type;


drop table Menu_item;
drop table Menu;

drop table Review;

drop table Restaurant;
drop table User;
